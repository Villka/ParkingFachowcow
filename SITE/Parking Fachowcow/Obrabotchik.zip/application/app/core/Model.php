<?php
/**
 *   
 *  Core file of Model
 *  Take data from DB and return it into Controller
 * 
**/
namespace app\core;

class Model
{
    /**
	 * method for returning data from model to controller
	 * @return all 
	 */
    public function getData()
    {

    }
}