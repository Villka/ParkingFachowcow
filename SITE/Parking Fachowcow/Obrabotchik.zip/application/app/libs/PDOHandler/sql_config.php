<?php

namespace app\libs\PDOHandler;

/** Error texts **/
define('ERR_VAL_COLUMNS', "Value of colums must be string or array type!");
define('ERR_VAL_TABLENAME', "Value of table name must be string type!");
define('ERR_VAL_CONDITIONS', "Conditions must be a string type!");
define('ERR_VAL_LIMIT', "Limit must be a numeric type!");
define('ERR_VAL_VALUES', "Values must be string or array type!");
define('ERR_VAL_UPDATE', "Columns and Values must be array type!");